import React, { useState, useEffect } from 'react'
import "./Navbar.css"
import logo from './logo_TechApp.png'
import panier from './panier_TechApp.png'
import recherche from './recherche_TechApp.png'

export default function Navbar() {

    const [toggleMenu, setToggleMenu] = useState(false);    //par defaut cacher le menu
    const [largeur, setLargeur] = useState(window.innerWidth);

    const toggleNavSmallScreen = () => { //permet de changer l'etat du menu (caché/pas caché)
        setToggleMenu(!toggleMenu);
    }

    useEffect(() => {
        const changeWidth = () => {
            setLargeur(window.innerWidth);

            if (window.innerWidth > 520) {//permet de recacher le menu
                setToggleMenu(false);
            }
        }

        window.addEventListener('resize', changeWidth);

        return () => {
            window.removeEventListener('resize', changeWidth);
        }
    }, [])

    return (
        <nav>
            <img className="logo" src={logo}></img>
            {(toggleMenu || largeur > 522) && (
                <ul className="liste">
                    <li className="items">Smartphone</li>
                    <li className="items">Tablette</li>
                    <li className="items">Ordianteur</li>
                    <li className="items">Enceinte</li>
                    <li className="items">Watch</li>
                </ul>
            )}
            <img className="icon" src={panier}></img>
            <img className="icon" src={recherche}></img>
            <button onClick={toggleNavSmallScreen} className="btn">BBB</button>
        </nav>
    )
}
